"""motphimz.ac scraper (dependency-free: urllib + regex).

The site is a Next.js app whose pages are server-rendered, so a plain HTTP GET
with a browser User-Agent returns everything we need — no JS, no Cloudflare
challenge, no Referer required for the streams (verified against the live site):

  listing  GET /danh-sach/phim-le|phim-bo|phim-moi , /the-loai/<g> , /quoc-gia/<c>
           , /search?keyword=...   (+ &page=N)
           -> movie cards: <a title="..." href="/phim/<slug>">
  film     GET /phim/<slug>
           -> embedded episode objects:
              {"server":"...","name":"Tập 01","slug":"...","type":"m3u8",
               "link":"https://.../index.m3u8"}
  stream   the episode "link" is already a direct HLS .m3u8 master playlist.

Posters derive from the slug: /storage/images/<base>/<base>-thumb.webp where
<base> is the slug minus its trailing -<digits> id.
"""
import html as _html
import re
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon

ADDON_ID = xbmcaddon.Addon().getAddonInfo("id")

BASE = "https://motphimz.ac"
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

# Top-level browse sections (label, path).
SECTIONS = (
    ("Phim Mới", "/danh-sach/phim-moi"),
    ("Phim Lẻ", "/danh-sach/phim-le"),
    ("Phim Bộ", "/danh-sach/phim-bo"),
)

# Genres (label, slug) under /the-loai/<slug>.
GENRES = (
    ("Hành Động", "hanh-dong"), ("Tình Cảm", "tinh-cam"), ("Hài Hước", "hai-huoc"),
    ("Cổ Trang", "co-trang"), ("Tâm Lý", "tam-ly"), ("Hình Sự", "hinh-su"),
    ("Chiến Tranh", "chien-tranh"), ("Thể Thao", "the-thao"), ("Võ Thuật", "vo-thuat"),
    ("Viễn Tưởng", "vien-tuong"), ("Phiêu Lưu", "phieu-luu"), ("Khoa Học", "khoa-hoc"),
    ("Kinh Dị", "kinh-di"), ("Âm Nhạc", "am-nhac"), ("Thần Thoại", "than-thoai"),
    ("Tài Liệu", "tai-lieu"), ("Gia Đình", "gia-dinh"), ("Chính Kịch", "chinh-kich"),
    ("Bí Ẩn", "bi-an"), ("Học Đường", "hoc-duong"), ("Kinh Điển", "kinh-dien"),
    ("Anime & Hoạt Hình", "hoat-hinh"), ("TV Shows", "tv-shows"),
)

# Countries (label, slug) under /quoc-gia/<slug>.
COUNTRIES = (
    ("Trung Quốc", "trung-quoc"), ("Hàn Quốc", "han-quoc"), ("Nhật Bản", "nhat-ban"),
    ("Thái Lan", "thai-lan"), ("Âu Mỹ", "au-my"), ("Đài Loan", "dai-loan"),
    ("Hồng Kông", "hong-kong"), ("Ấn Độ", "an-do"), ("Anh", "anh"),
    ("Pháp", "phap"), ("Canada", "canada"), ("Nga", "nga"),
)

_CARD = re.compile(r'<a\s+title="([^"]+)"[^>]*?href="(/phim/[^"#?]+)"')
# Search results (and some grids) are rendered in the Next.js flight payload as
# escaped JSON instead of HTML cards: ...\"href\":\"/phim/<slug>\"...\"alt\":\"Title\"
_FLIGHT = re.compile(r'\\"href\\":\\"(/phim/[^"\\#?]+)\\"')
_ALT = re.compile(r'\\"alt\\":\\"([^"\\]+)\\"')
# Episode objects carry the owning movie's id. The film page embeds not just
# this film's episodes but also those of related/suggested titles (which reuse
# the same server names), so we must filter to this film's movie_id.
_EP = re.compile(
    r'\\"movie_id\\":\\"([^"\\]*)\\",\\"server\\":\\"([^"\\]*)\\",'
    r'\\"name\\":\\"([^"\\]*)\\",\\"slug\\":\\"([^"\\]*)\\",'
    r'\\"type\\":\\"([^"\\]*)\\",\\"link\\":\\"([^"\\]*)\\"')
# The film's own episode list sits under this section header; the first
# movie_id after it identifies which episodes belong to this film.
_EP_SECTION = "Danh sách tập phim"
_EP_MOVIE_ID = re.compile(r'\\"movie_id\\":\\"([^"\\]*)\\"')
_TITLE = re.compile(r"<title>([^<]+)</title>")
# Synopsis: the "Nội dung phim" tab's prose block on the film page.
_PLOT = re.compile(
    r'Nội dung phim:.*?</h2>\s*<div[^>]*class="[^"]*prose[^"]*"[^>]*>(.*?)</div>', re.S)
_TAGS = re.compile(r"<[^>]+>")
_WS = re.compile(r"\s+")
# English/original title (JSON-LD movie object) and the "(English)" in the
# "Nội dung phim" header as a fallback.
_ALTNAME = re.compile(r'"alternateName"\s*:\s*"([^"]+)"')
_HEADER_EN = re.compile(r"Nội dung phim:.*?\(([^)<]+)\)\s*</h2>", re.S)


class MotPhimError(Exception):
    """Network/parse failure with a user-facing message."""


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] motphim: {}".format(ADDON_ID, msg), level)


def _get(url):
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html"})
    try:
        with urlopen(req, timeout=20) as resp:
            return resp.read().decode("utf-8", "replace")
    except HTTPError as exc:
        raise MotPhimError("motphimz returned HTTP {}.".format(exc.code))
    except URLError as exc:
        raise MotPhimError("Network error contacting motphimz: {}".format(exc.reason))


def _slug(path):
    return path.rstrip("/").split("/")[-1]


def _poster(slug):
    base = re.sub(r"-\d+$", "", slug)
    return "{}/storage/images/{}/{}-thumb.webp".format(BASE, base, base)


def poster_url(slug):
    """Public poster URL for a film slug (same derivation as listing cards)."""
    return _poster(slug)


def _parse_cards(body):
    """Server-rendered HTML cards: <a title="..." href="/phim/slug">."""
    seen, items = set(), []
    for title, href in _CARD.findall(body):
        slug = _slug(href)
        if slug in seen:
            continue
        seen.add(slug)
        items.append({"name": _html.unescape(title), "slug": slug, "poster": _poster(slug)})
    return items


def _parse_flight(body):
    """Next.js flight payload items: \\"href\\":\\"/phim/slug\\" + nearby alt."""
    seen, items = set(), []
    for m in _FLIGHT.finditer(body):
        slug = _slug(m.group(1))
        if slug in seen:
            continue
        seen.add(slug)
        alt = _ALT.search(body, m.end(), m.end() + 500)
        name = _html.unescape(alt.group(1)) if alt else slug.rsplit("-", 1)[0].replace("-", " ").title()
        items.append({"name": name, "slug": slug, "poster": _poster(slug)})
    return items


def list_movies(path, page=1):
    """Return (items, has_next) for a listing path.

    Pagination is a path segment: /danh-sach/phim-le/2 , /the-loai/<g>/2 , etc.
    (query/`/trang-N` forms are ignored by the site and re-serve page 1). Search
    (`/search?keyword=`) is single-page — no pagination. Listing grids are HTML
    cards; search results come back only in the flight payload, so fall back to
    that when no cards are present. `has_next` is true only when the page's
    pagination actually links to page+1.
    """
    is_search = path.startswith("/search")
    if is_search:
        url = BASE + path
    else:
        url = BASE + path + ("/{}".format(page) if page > 1 else "")
    body = _get(url)
    items = _parse_cards(body) or _parse_flight(body)
    has_next = (not is_search
                and bool(items)
                and 'href="{}/{}"'.format(path, page + 1) in body)
    return items, has_next


def search_path(keyword):
    return "/search?keyword=" + quote(keyword)


def _plot(body):
    m = _PLOT.search(body)
    if not m:
        return ""
    return _html.unescape(_WS.sub(" ", _TAGS.sub("", m.group(1)))).strip()


def _english_name(body):
    m = _ALTNAME.search(body)
    if m:
        return _html.unescape(m.group(1)).strip()
    m = _HEADER_EN.search(body)
    return _html.unescape(m.group(1)).strip() if m else ""


def _film_movie_id(body):
    """The movie_id whose episodes belong to this film.

    The episode list renders under the "Danh sách tập phim" header, so the
    first movie_id after that marker is this film's. Fall back to the first
    movie_id on the page (the film's own block renders before related titles').
    """
    i = body.find(_EP_SECTION)
    m = _EP_MOVIE_ID.search(body, i) if i != -1 else _EP_MOVIE_ID.search(body)
    return m.group(1) if m else ""


def get_film(slug):
    """Return (title, en_name, plot, [server,...], {server: [{name,link,type}]}).

    Episodes are deduped (the page embeds them more than once) and grouped by
    server so the user can pick Vietsub / Thuyết Minh / mirrors. ``plot`` is the
    "Nội dung phim" synopsis; ``en_name`` is the English/original title (used
    for the IMDb lookup).
    """
    body = _get("{}/phim/{}".format(BASE, slug))

    title = ""
    m = _TITLE.search(body)
    if m:
        title = _html.unescape(m.group(1)).split(" - ")[0].strip()
        title = re.sub(r"^Phim\s+", "", title)
    en_name = _english_name(body)
    plot = _plot(body)

    # Restrict to this film's episodes (the page also embeds related titles').
    target_id = _film_movie_id(body)

    servers, by_server, seen = [], {}, set()
    for movie_id, srv, name, ep_slug, typ, link in _EP.findall(body):
        if target_id and movie_id != target_id:
            continue
        link = link.replace("\\/", "/")
        if not link.startswith("http"):
            continue
        key = (srv, ep_slug or name)
        if key in seen:
            continue
        seen.add(key)
        if srv not in by_server:
            by_server[srv] = []
            servers.append(srv)
        by_server[srv].append({"name": name or "Full", "link": link, "type": typ})
    return title, en_name, plot, servers, by_server


def get_episodes(slug, server):
    """Return (en_name, plot, [episodes]) for one server of a film."""
    _, en_name, plot, _, by_server = get_film(slug)
    return en_name, plot, by_server.get(server, [])
