"""URL routing and view dispatch for the Home Media add-on."""
from urllib.parse import parse_qsl, urlencode

import xbmcplugin

from resources.lib import views


def build_url(base_url, **kwargs):
    """Build a plugin:// URL for a list item, e.g. build_url(base, action='list')."""
    return "{}?{}".format(base_url, urlencode(kwargs))


def run(argv):
    """Parse the invocation argv and dispatch to the matching view."""
    base_url = argv[0]
    handle = int(argv[1])
    params = dict(parse_qsl(argv[2][1:]))  # strip leading '?'

    action = params.get("action", "root")

    routes = {
        "root": views.root,
        "favorites": views.favorites,
        "folder": views.folder,
        "play": views.play,
        # MotPhim source
        "mp_home": views.mp_home,
        "mp_genres": views.mp_genres,
        "mp_search": views.mp_search,
        "mp_list": views.mp_list,
        "mp_film": views.mp_film,
        "mp_server": views.mp_server,
        "mp_play": views.mp_play,
    }

    handler = routes.get(action, views.root)
    handler(handle, base_url, params)

    # Playback actions resolve a URL instead of populating a directory.
    if action not in RESOLVE_ACTIONS:
        xbmcplugin.endOfDirectory(handle)


# Actions that call setResolvedUrl and must not end a directory listing.
RESOLVE_ACTIONS = {"play", "mp_play"}
