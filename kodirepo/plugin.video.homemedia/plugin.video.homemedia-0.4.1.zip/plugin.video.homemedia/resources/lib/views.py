"""View handlers: build directory listings and resolve playback."""
import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import fshare, motphim, router


def _notify(message):
    xbmcgui.Dialog().notification("Home Media", message, xbmcgui.NOTIFICATION_ERROR)


def _add_item(handle, base_url, item):
    """Add one normalised Fshare item ({name, linkcode, is_folder}) to the list."""
    li = xbmcgui.ListItem(label=item["name"])
    if item["is_folder"]:
        li.setArt({"icon": "DefaultFolder.png"})
        url = router.build_url(base_url, action="folder", linkcode=item["linkcode"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    else:
        li.setProperty("IsPlayable", "true")
        li.setArt({"icon": "DefaultVideo.png"})
        info = li.getVideoInfoTag()
        info.setTitle(item["name"])
        info.setMediaType("video")
        url = router.build_url(base_url, action="play", linkcode=item["linkcode"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)


def _render(handle, base_url, items):
    for item in items:
        _add_item(handle, base_url, item)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)


# Top-level media sources. Add new entries here as they are developed; each
# maps a display label to the action that lists it.
SOURCES = (
    {"label": "Fshare Favorites", "action": "favorites", "icon": "DefaultFavourites.png"},
    {"label": "MotPhim", "action": "mp_home", "icon": "DefaultMovies.png"},
)


def root(handle, base_url, params):
    """Top level = the list of media sources."""
    xbmcplugin.setPluginCategory(handle, "Home Media")
    xbmcplugin.setContent(handle, "files")
    for source in SOURCES:
        li = xbmcgui.ListItem(label=source["label"])
        li.setArt({"icon": source.get("icon", "DefaultFolder.png")})
        url = router.build_url(base_url, action=source["action"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)


def favorites(handle, base_url, params):
    """The Fshare Favorites source: the account's favorites/bookmarks."""
    xbmcplugin.setPluginCategory(handle, "Fshare Favorites")
    xbmcplugin.setContent(handle, "videos")
    try:
        items = fshare.get_favorites()
    except fshare.FshareError as exc:
        _notify(str(exc))
        return
    if not items:
        xbmcgui.Dialog().notification("Home Media", "No favorites found.")
    _render(handle, base_url, items)


def folder(handle, base_url, params):
    """Browse the contents of a favorited Fshare folder."""
    xbmcplugin.setContent(handle, "videos")
    try:
        items = fshare.list_folder(params.get("linkcode", ""))
    except fshare.FshareError as exc:
        _notify(str(exc))
        return
    _render(handle, base_url, items)


def play(handle, base_url, params):
    """Resolve the selected file to a direct stream and hand it to Kodi."""
    try:
        location = fshare.resolve_download(params.get("linkcode", ""))
    except fshare.FshareError as exc:
        _notify(str(exc))
        xbmcplugin.setResolvedUrl(handle, succeeded=False, listitem=xbmcgui.ListItem())
        return
    item = xbmcgui.ListItem(path=location)
    xbmcplugin.setResolvedUrl(handle, succeeded=True, listitem=item)


# --- MotPhim source --------------------------------------------------------

def _mp_folder(handle, base_url, label, action, art="DefaultFolder.png", **extra):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": art})
    url = router.build_url(base_url, action=action, **extra)
    xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)


def mp_home(handle, base_url, params):
    """MotPhim source landing: browse sections, genres, and search."""
    xbmcplugin.setPluginCategory(handle, "MotPhim")
    xbmcplugin.setContent(handle, "files")
    for label, path in motphim.SECTIONS:
        _mp_folder(handle, base_url, label, "mp_list", "DefaultMovies.png", path=path)
    _mp_folder(handle, base_url, "Thể Loại", "mp_genres", "DefaultGenre.png")
    _mp_folder(handle, base_url, "Tìm Kiếm", "mp_search", "DefaultAddonsSearch.png")


def mp_genres(handle, base_url, params):
    xbmcplugin.setPluginCategory(handle, "Thể Loại")
    for label, slug in motphim.GENRES:
        _mp_folder(handle, base_url, label, "mp_list", path="/the-loai/" + slug)


def mp_search(handle, base_url, params):
    keyword = params.get("q")
    if not keyword:
        kb = xbmc.Keyboard("", "Tìm phim")
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            return
        keyword = kb.getText().strip()
    _mp_list_render(handle, base_url, motphim.search_path(keyword), 1)


def mp_list(handle, base_url, params):
    _mp_list_render(handle, base_url, params.get("path", ""),
                    int(params.get("page", 1)))


def _mp_list_render(handle, base_url, path, page):
    xbmcplugin.setContent(handle, "movies")
    try:
        items, has_next = motphim.list_movies(path, page)
    except motphim.MotPhimError as exc:
        _notify(str(exc))
        return
    for it in items:
        li = xbmcgui.ListItem(label=it["name"])
        li.setArt({"thumb": it["poster"], "poster": it["poster"]})
        info = li.getVideoInfoTag()
        info.setTitle(it["name"])
        info.setMediaType("video")
        url = router.build_url(base_url, action="mp_film", slug=it["slug"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    if has_next:
        nli = xbmcgui.ListItem(label="Trang sau >>")
        nli.setArt({"icon": "DefaultFolderBack.png"})
        nurl = router.build_url(base_url, action="mp_list", path=path, page=page + 1)
        xbmcplugin.addDirectoryItem(handle, nurl, nli, isFolder=True)


def mp_film(handle, base_url, params):
    """Show a film's servers (Vietsub / Thuyết Minh / mirrors)."""
    slug = params.get("slug", "")
    try:
        title, servers, by_server = motphim.get_film(slug)
    except motphim.MotPhimError as exc:
        _notify(str(exc))
        return
    if not servers:
        _notify("No playable source found.")
        return
    # Single server → skip straight to its episodes.
    if len(servers) == 1:
        _mp_episodes_render(handle, base_url, by_server[servers[0]])
        return
    xbmcplugin.setPluginCategory(handle, title or "MotPhim")
    for srv in servers:
        _mp_folder(handle, base_url, srv, "mp_server", "DefaultVideoPlaylists.png",
                   slug=slug, server=srv)


def mp_server(handle, base_url, params):
    try:
        eps = motphim.get_episodes(params.get("slug", ""), params.get("server", ""))
    except motphim.MotPhimError as exc:
        _notify(str(exc))
        return
    _mp_episodes_render(handle, base_url, eps)


def _mp_episodes_render(handle, base_url, eps):
    xbmcplugin.setContent(handle, "episodes")
    for ep in eps:
        li = xbmcgui.ListItem(label=ep["name"])
        li.setProperty("IsPlayable", "true")
        info = li.getVideoInfoTag()
        info.setTitle(ep["name"])
        info.setMediaType("video")
        url = router.build_url(base_url, action="mp_play", link=ep["link"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)


def mp_play(handle, base_url, params):
    """Hand the direct HLS stream to Kodi via inputstream.adaptive."""
    link = params.get("link", "")
    li = xbmcgui.ListItem(path=link)
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)
    li.setProperty("inputstream", "inputstream.adaptive")
    li.setProperty("inputstream.adaptive.manifest_type", "hls")
    xbmcplugin.setResolvedUrl(handle, succeeded=bool(link), listitem=li)
