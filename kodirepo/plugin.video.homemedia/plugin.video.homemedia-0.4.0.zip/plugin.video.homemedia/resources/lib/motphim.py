"""motphimz.ac scraper (dependency-free: urllib + regex).

The site is a Next.js app whose pages are server-rendered, so a plain HTTP GET
with a browser User-Agent returns everything we need — no JS, no Cloudflare
challenge, no Referer required for the streams (verified against the live site):

  listing  GET /danh-sach/phim-le|phim-bo|phim-moi , /the-loai/<g> , /quoc-gia/<c>
           , /search?keyword=...   (+ &page=N)
           -> movie cards: <a title="..." href="/phim/<slug>">
  film     GET /phim/<slug>
           -> embedded episode objects:
              {"server":"...","name":"Tập 01","slug":"...","type":"m3u8",
               "link":"https://.../index.m3u8"}
  stream   the episode "link" is already a direct HLS .m3u8 master playlist.

Posters derive from the slug: /storage/images/<base>/<base>-thumb.webp where
<base> is the slug minus its trailing -<digits> id.
"""
import html as _html
import re
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon

ADDON_ID = xbmcaddon.Addon().getAddonInfo("id")

BASE = "https://motphimz.ac"
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

# Top-level browse sections (label, path).
SECTIONS = (
    ("Phim Mới", "/danh-sach/phim-moi"),
    ("Phim Lẻ", "/danh-sach/phim-le"),
    ("Phim Bộ", "/danh-sach/phim-bo"),
)

# Genres (label, slug) under /the-loai/<slug>.
GENRES = (
    ("Hành Động", "hanh-dong"), ("Tình Cảm", "tinh-cam"), ("Hài Hước", "hai-huoc"),
    ("Cổ Trang", "co-trang"), ("Tâm Lý", "tam-ly"), ("Hình Sự", "hinh-su"),
    ("Chiến Tranh", "chien-tranh"), ("Thể Thao", "the-thao"), ("Võ Thuật", "vo-thuat"),
    ("Viễn Tưởng", "vien-tuong"), ("Phiêu Lưu", "phieu-luu"), ("Khoa Học", "khoa-hoc"),
    ("Kinh Dị", "kinh-di"), ("Âm Nhạc", "am-nhac"), ("Thần Thoại", "than-thoai"),
    ("Tài Liệu", "tai-lieu"), ("Gia Đình", "gia-dinh"), ("Chính Kịch", "chinh-kich"),
    ("Bí Ẩn", "bi-an"), ("Học Đường", "hoc-duong"), ("Kinh Điển", "kinh-dien"),
    ("Anime & Hoạt Hình", "hoat-hinh"), ("TV Shows", "tv-shows"),
)

_CARD = re.compile(r'<a\s+title="([^"]+)"[^>]*?href="(/phim/[^"#?]+)"')
# Search results (and some grids) are rendered in the Next.js flight payload as
# escaped JSON instead of HTML cards: ...\"href\":\"/phim/<slug>\"...\"alt\":\"Title\"
_FLIGHT = re.compile(r'\\"href\\":\\"(/phim/[^"\\#?]+)\\"')
_ALT = re.compile(r'\\"alt\\":\\"([^"\\]+)\\"')
_EP = re.compile(
    r'\\"server\\":\\"([^"\\]*)\\",\\"name\\":\\"([^"\\]*)\\",'
    r'\\"slug\\":\\"([^"\\]*)\\",\\"type\\":\\"([^"\\]*)\\",\\"link\\":\\"([^"\\]*)\\"')
_TITLE = re.compile(r"<title>([^<]+)</title>")


class MotPhimError(Exception):
    """Network/parse failure with a user-facing message."""


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] motphim: {}".format(ADDON_ID, msg), level)


def _get(url):
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html"})
    try:
        with urlopen(req, timeout=20) as resp:
            return resp.read().decode("utf-8", "replace")
    except HTTPError as exc:
        raise MotPhimError("motphimz returned HTTP {}.".format(exc.code))
    except URLError as exc:
        raise MotPhimError("Network error contacting motphimz: {}".format(exc.reason))


def _slug(path):
    return path.rstrip("/").split("/")[-1]


def _poster(slug):
    base = re.sub(r"-\d+$", "", slug)
    return "{}/storage/images/{}/{}-thumb.webp".format(BASE, base, base)


def _parse_cards(body):
    """Server-rendered HTML cards: <a title="..." href="/phim/slug">."""
    seen, items = set(), []
    for title, href in _CARD.findall(body):
        slug = _slug(href)
        if slug in seen:
            continue
        seen.add(slug)
        items.append({"name": _html.unescape(title), "slug": slug, "poster": _poster(slug)})
    return items


def _parse_flight(body):
    """Next.js flight payload items: \\"href\\":\\"/phim/slug\\" + nearby alt."""
    seen, items = set(), []
    for m in _FLIGHT.finditer(body):
        slug = _slug(m.group(1))
        if slug in seen:
            continue
        seen.add(slug)
        alt = _ALT.search(body, m.end(), m.end() + 500)
        name = _html.unescape(alt.group(1)) if alt else slug.rsplit("-", 1)[0].replace("-", " ").title()
        items.append({"name": name, "slug": slug, "poster": _poster(slug)})
    return items


def list_movies(path, page=1):
    """Return movie cards [{name, slug, poster}] for a listing path.

    Listing grids are HTML cards; search results come back only in the flight
    payload, so fall back to that when no cards are present.
    """
    sep = "&" if "?" in path else "?"
    body = _get("{}{}{}page={}".format(BASE, path, sep, page))
    return _parse_cards(body) or _parse_flight(body)


def search(keyword, page=1):
    return list_movies("/search?keyword=" + quote(keyword), page)


def get_film(slug):
    """Return (title, [server_name,...], {server_name: [{name, link, type}]}).

    Episodes are deduped (the page embeds them more than once) and grouped by
    server so the user can pick Vietsub / Thuyết Minh / mirrors.
    """
    body = _get("{}/phim/{}".format(BASE, slug))

    title = ""
    m = _TITLE.search(body)
    if m:
        title = _html.unescape(m.group(1)).split(" - ")[0].strip()
        title = re.sub(r"^Phim\s+", "", title)

    servers, by_server, seen = [], {}, set()
    for srv, name, ep_slug, typ, link in _EP.findall(body):
        link = link.replace("\\/", "/")
        if not link.startswith("http"):
            continue
        key = (srv, ep_slug or name)
        if key in seen:
            continue
        seen.add(key)
        if srv not in by_server:
            by_server[srv] = []
            servers.append(srv)
        by_server[srv].append({"name": name or "Full", "link": link, "type": typ})
    return title, servers, by_server


def get_episodes(slug, server):
    _, _, by_server = get_film(slug)
    return by_server.get(server, [])
