"""View handlers: build directory listings and resolve playback via Fshare."""
import xbmcgui
import xbmcplugin

from resources.lib import fshare, router


def _notify(message):
    xbmcgui.Dialog().notification("Home Media", message, xbmcgui.NOTIFICATION_ERROR)


def _add_item(handle, base_url, item):
    """Add one normalised Fshare item ({name, linkcode, is_folder}) to the list."""
    li = xbmcgui.ListItem(label=item["name"])
    if item["is_folder"]:
        li.setArt({"icon": "DefaultFolder.png"})
        url = router.build_url(base_url, action="folder", linkcode=item["linkcode"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)
    else:
        li.setProperty("IsPlayable", "true")
        li.setArt({"icon": "DefaultVideo.png"})
        info = li.getVideoInfoTag()
        info.setTitle(item["name"])
        info.setMediaType("video")
        url = router.build_url(base_url, action="play", linkcode=item["linkcode"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)


def _render(handle, base_url, items):
    for item in items:
        _add_item(handle, base_url, item)
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)


def root(handle, base_url, params):
    """Top level = the account's Fshare favorites/bookmarks."""
    xbmcplugin.setPluginCategory(handle, "My Fshare Favorites")
    xbmcplugin.setContent(handle, "videos")
    try:
        items = fshare.get_favorites()
    except fshare.FshareError as exc:
        _notify(str(exc))
        return
    if not items:
        xbmcgui.Dialog().notification("Home Media", "No favorites found.")
    _render(handle, base_url, items)


def folder(handle, base_url, params):
    """Browse the contents of a favorited Fshare folder."""
    xbmcplugin.setContent(handle, "videos")
    try:
        items = fshare.list_folder(params.get("linkcode", ""))
    except fshare.FshareError as exc:
        _notify(str(exc))
        return
    _render(handle, base_url, items)


def play(handle, base_url, params):
    """Resolve the selected file to a direct stream and hand it to Kodi."""
    try:
        location = fshare.resolve_download(params.get("linkcode", ""))
    except fshare.FshareError as exc:
        _notify(str(exc))
        xbmcplugin.setResolvedUrl(handle, succeeded=False, listitem=xbmcgui.ListItem())
        return
    item = xbmcgui.ListItem(path=location)
    xbmcplugin.setResolvedUrl(handle, succeeded=True, listitem=item)
