"""Look up an IMDb rating by (English) title — key-free, with caching.

Flow (all endpoints free, no API key):
  1. IMDb suggestion API resolves a title to its tt id:
       https://v3.sg.media-imdb.com/suggestion/x/<query>.json
  2. IMDb's public GraphQL returns the live rating for that id (authoritative,
     covers brand-new titles):
       POST https://api.graphql.imdb.com/  { title(id).ratingsSummary.aggregateRating }
     Falls back to Cinemeta (https://v3-cinemeta.strem.io) if GraphQL is empty.

Returns a string formatted as "x.x" (one decimal) or "n/a". Ratings are cached
in the add-on profile (positive results 30 days, "n/a" 1 day so transient
failures retry). Lookups never raise — a rating is non-critical decoration.
"""
import json
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

SUGGEST = "https://v3.sg.media-imdb.com/suggestion/x/{}.json"
GRAPHQL = "https://api.graphql.imdb.com/"
CINEMETA = "https://v3-cinemeta.strem.io/meta/{}/{}.json"
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
POS_TTL = 30 * 24 * 3600
NEG_TTL = 24 * 3600
NA = "n/a"


def _cache_file():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return profile + "imdb.json"


def _load():
    path = _cache_file()
    if not xbmcvfs.exists(path):
        return {}
    try:
        with xbmcvfs.File(path) as fh:
            return json.loads(fh.read())
    except (ValueError, IOError):
        return {}


def _save(cache):
    try:
        with xbmcvfs.File(_cache_file(), "w") as fh:
            fh.write(json.dumps(cache))
    except IOError:
        pass


def _http_json(url, data=None, headers=None):
    head = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if headers:
        head.update(headers)
    req = Request(url, data=data, headers=head)
    with urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8", "replace"))


def _graphql_rating(tt):
    query = 'query{title(id:"%s"){ratingsSummary{aggregateRating}}}' % tt
    body = json.dumps({"query": query}).encode("utf-8")
    try:
        data = _http_json(GRAPHQL, data=body, headers={"Content-Type": "application/json"})
    except (HTTPError, URLError, ValueError):
        return None
    summary = (((data.get("data") or {}).get("title") or {}).get("ratingsSummary") or {})
    return summary.get("aggregateRating")


def _cinemeta_rating(tt):
    for kind in ("movie", "series"):
        try:
            meta = (_http_json(CINEMETA.format(kind, tt)).get("meta") or {})
        except (HTTPError, URLError, ValueError):
            continue
        if meta.get("imdbRating"):
            return meta["imdbRating"]
    return None


def _lookup(name):
    data = _http_json(SUGGEST.format(quote(name)))
    items = [i for i in data.get("d", []) if str(i.get("id", "")).startswith("tt")]
    if not items:
        return NA
    tt = items[0]["id"]
    value = _graphql_rating(tt) or _cinemeta_rating(tt)
    if not value:
        return NA
    try:
        return "{:.1f}".format(float(value))
    except (TypeError, ValueError):
        return NA


def rating(name):
    """Return the IMDb rating for an (English) title as "x.x" or "n/a"."""
    name = (name or "").strip()
    if not name:
        return NA
    cache = _load()
    entry = cache.get(name)
    now = time.time()
    if entry:
        ttl = NEG_TTL if entry.get("v") == NA else POS_TTL
        if now - entry.get("ts", 0) < ttl:
            return entry["v"]
    try:
        value = _lookup(name)
    except (HTTPError, URLError, ValueError, OSError) as exc:
        xbmc.log("[{}] imdb lookup failed for {!r}: {}".format(ADDON_ID, name, exc),
                 xbmc.LOGWARNING)
        value = NA
    cache[name] = {"v": value, "ts": now}
    _save(cache)
    return value
