"""Fshare.vn API client.

Dependency-free (urllib only). Handles login with cached session, resolving
direct download links, listing folder contents, and fetching the account's
favorites/bookmarks.

NOTE ON THE FAVORITES ENDPOINT
------------------------------
Fshare suspended public API docs for individual users, and the favorites /
"follows" list endpoint is not publicly documented. We therefore PROBE a small
set of candidate endpoints at runtime (see FAVORITE_ENDPOINTS) and use the
first that returns a usable list, logging the raw body so the working endpoint
can be pinned down from kodi.log if the defaults ever change. Items are parsed
flexibly (anything that looks like an Fshare file/folder).

Confirmed-working endpoints (community clients):
    POST {API_BASE}/user/login        -> {token, session_id}
    POST {API_BASE}/session/download  -> {location}
    GET  {WEB_BASE}/api/v3/files/folder?linkcode=...   -> folder contents
"""
import json
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

API_BASE = "https://api.fshare.vn/api"          # auth + download (v2)
WEB_BASE = "https://www.fshare.vn"              # v3 file/folder + favorites
# Public app_key used by community clients; overridable in advanced settings.
DEFAULT_APP_KEY = "dMnqMMZMUnN5YpvKENaEhdQQ5jxDqddt"
USER_AGENT = "okhttp/3.6.0"
# Session is reused for ~6h; we also re-login automatically on a 401/expiry.
SESSION_TTL = 6 * 60 * 60

# Favorites/bookmarks endpoint on the fshare.vn web API. Tried in order; the
# first that yields parseable items wins. Fallbacks kept in case the API
# changes again.
FAVORITE_ENDPOINTS = (
    WEB_BASE + "/api/v3/favorites?sort=-modified&page=1&per-page=100",
    WEB_BASE + "/api/v3/favorites?sort=-modified",
    WEB_BASE + "/api/v3/favorites",
    WEB_BASE + "/api/v3/files/favorite?sort=type,name&per-page=100",
)


class FshareError(Exception):
    """Raised for any auth/network/API failure with a user-facing message."""


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, msg), level)


def _app_key():
    return ADDON.getSetting("app_key") or DEFAULT_APP_KEY


# --- session cache ---------------------------------------------------------

def _session_file():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return profile + "session.json"


def _load_session():
    path = _session_file()
    if not xbmcvfs.exists(path):
        return None
    try:
        with xbmcvfs.File(path) as fh:
            data = json.loads(fh.read())
    except (ValueError, IOError):
        return None
    if time.time() - data.get("ts", 0) > SESSION_TTL:
        return None
    return data


def _save_session(token, session_id):
    payload = {"token": token, "session_id": session_id, "ts": time.time()}
    with xbmcvfs.File(_session_file(), "w") as fh:
        fh.write(json.dumps(payload))


def _clear_session():
    path = _session_file()
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)


# --- low-level HTTP --------------------------------------------------------

def _request(url, method="GET", json_body=None, session_id=None):
    """Perform an HTTP request; return (status, parsed_json_or_text)."""
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    data = None
    if json_body is not None:
        data = json.dumps(json_body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if session_id:
        headers["Cookie"] = "session_id=" + session_id

    req = Request(url, data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=20) as resp:
            raw = resp.read().decode("utf-8", "replace")
            status = resp.getcode()
    except HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace") if exc.fp else ""
        status = exc.code
    except URLError as exc:
        raise FshareError("Network error contacting Fshare: {}".format(exc.reason))

    try:
        return status, json.loads(raw)
    except ValueError:
        return status, raw


# --- auth ------------------------------------------------------------------

def login(force=False):
    """Return (token, session_id), reusing a cached session unless forced."""
    if not force:
        cached = _load_session()
        if cached:
            return cached["token"], cached["session_id"]

    email = ADDON.getSetting("email")
    password = ADDON.getSetting("password")
    if not email or not password:
        raise FshareError("Enter your Fshare email and password in add-on settings.")

    status, body = _request(
        API_BASE + "/user/login",
        method="POST",
        json_body={"app_key": _app_key(), "user_email": email, "password": password},
    )
    if status != 200 or not isinstance(body, dict) or not body.get("token"):
        msg = body.get("msg") if isinstance(body, dict) else str(body)[:200]
        raise FshareError("Fshare login failed: {}".format(msg or status))

    token, session_id = body["token"], body.get("session_id", "")
    _save_session(token, session_id)
    log("Logged in to Fshare for {}".format(email))
    return token, session_id


def _authed(url, method="GET", json_body=None):
    """Request with the session cookie, transparently re-logging in on 401."""
    token, session_id = login()
    status, body = _request(url, method, json_body, session_id)
    if status in (401, 403):
        _clear_session()
        token, session_id = login(force=True)
        status, body = _request(url, method, json_body, session_id)
    return status, body, token, session_id


# --- helpers ---------------------------------------------------------------

def linkcode_of(url):
    """Extract the trailing linkcode from an Fshare file/folder URL."""
    return url.rstrip("/").split("/")[-1] if url else ""


def is_folder_url(url):
    return "/folder/" in (url or "")


def _as_items(payload):
    """Walk an arbitrary Fshare JSON envelope and pull out file/folder items.

    Different candidate endpoints wrap the list differently (``items``,
    ``data``, ``current``, or a bare list), so we recurse and collect any dict
    that carries a recognisable name + Fshare URL/linkcode.
    """
    found = []

    def looks_like_item(d):
        name = d.get("name") or d.get("title") or d.get("file_name")
        link = d.get("url") or d.get("linkcode") or d.get("file_link")
        return bool(name and link)

    def walk(node):
        if isinstance(node, dict):
            if looks_like_item(node):
                found.append(node)
            else:
                for v in node.values():
                    walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)

    walk(payload)
    return found


def _normalise(raw):
    """Map a raw Fshare item dict to {name, url, is_folder, linkcode}."""
    name = raw.get("name") or raw.get("title") or raw.get("file_name") or "Untitled"
    url = raw.get("url") or raw.get("file_link") or ""
    linkcode = raw.get("linkcode") or linkcode_of(url)
    if not url and linkcode:
        kind = "folder" if str(raw.get("type", "")) in ("1", "folder") else "file"
        url = "{}/{}/{}".format(WEB_BASE, kind, linkcode)
    folder = is_folder_url(url) or str(raw.get("type", "")) in ("1", "folder")
    return {"name": name, "url": url, "is_folder": folder, "linkcode": linkcode}


# --- public API ------------------------------------------------------------

def get_favorites():
    """Return the account's favorites/bookmarks as normalised item dicts.

    Probes FAVORITE_ENDPOINTS and uses the first that yields items.
    """
    last_status = None
    for endpoint in FAVORITE_ENDPOINTS:
        status, body, _, _ = _authed(endpoint)
        last_status = status
        if status != 200:
            log("favorites probe {} -> HTTP {}".format(endpoint, status), xbmc.LOGDEBUG)
            continue
        items = _as_items(body)
        log("favorites probe {} -> {} item(s)".format(endpoint, len(items)))
        if items:
            return [_normalise(i) for i in items]
    # No endpoint produced items. Log a snippet to help pin the real one down.
    raise FshareError(
        "Couldn't read your Fshare favorites (last HTTP {}). The favorites API "
        "endpoint may have changed — see kodi.log for the probe results.".format(last_status)
    )


def list_folder(folder_url, page=1, per_page=100):
    """Return normalised items inside an Fshare folder URL."""
    code = linkcode_of(folder_url)
    qs = urlencode({"linkcode": code, "sort": "type,name", "page": page, "per-page": per_page})
    status, body, _, _ = _authed("{}/api/v3/files/folder?{}".format(WEB_BASE, qs))
    if status != 200:
        raise FshareError("Couldn't list folder (HTTP {}).".format(status))
    return [_normalise(i) for i in _as_items(body)]


def resolve_download(file_url):
    """Resolve an Fshare file URL to a direct, streamable link.

    The download body must carry the current token, so we build the request
    after logging in and retry once with a fresh session on auth failure.
    """
    for attempt in range(2):
        token, session_id = login(force=attempt > 0)
        status, body = _request(
            API_BASE + "/session/download",
            method="POST",
            json_body={"token": token, "url": file_url, "password": ""},
            session_id=session_id,
        )
        if isinstance(body, dict) and body.get("location"):
            return body["location"]
        if status in (401, 403):
            _clear_session()
            continue
        break
    msg = body.get("msg") if isinstance(body, dict) else str(body)[:200]
    raise FshareError("Couldn't get download link: {}".format(msg or status))
