"""URL routing and view dispatch for the Home Media add-on."""
from urllib.parse import parse_qsl, urlencode

import xbmcplugin

from resources.lib import views


def build_url(base_url, **kwargs):
    """Build a plugin:// URL for a list item, e.g. build_url(base, action='list')."""
    return "{}?{}".format(base_url, urlencode(kwargs))


def run(argv):
    """Parse the invocation argv and dispatch to the matching view."""
    base_url = argv[0]
    handle = int(argv[1])
    params = dict(parse_qsl(argv[2][1:]))  # strip leading '?'

    action = params.get("action", "root")

    routes = {
        "root": views.root,
        "favorites": views.favorites,
        "folder": views.folder,
        "play": views.play,
    }

    handler = routes.get(action, views.root)
    handler(handle, base_url, params)

    # Signal Kodi that directory population is complete (no-op for play actions).
    if action != "play":
        xbmcplugin.endOfDirectory(handle)
