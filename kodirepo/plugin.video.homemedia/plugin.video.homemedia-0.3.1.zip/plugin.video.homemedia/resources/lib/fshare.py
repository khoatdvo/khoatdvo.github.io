"""Fshare.vn API client (dependency-free, urllib only).

Auth + data flow, all verified against a live account:

  login   POST https://api2.fshare.vn/api/user/login
          body {app_key, user_email, password}, UA "okhttp/3.6.0"
          -> {code:200, token, session_id}
  Then every web API call is authenticated with an Authorization: Bearer
  header. The web app uses the session token as the bearer; we try session_id
  first and fall back to token, caching whichever the API accepts.

  favorites GET  /api/v3/favorites/explore?sort=-modified   -> {items:[...]}
  folder    GET  /api/v3/files/folder?linkcode=&page=&per-page= -> {items:[...]}
  download  GET  /api/v3/files/download?dl_type=media&linkcode= -> "<direct url>"

Item types: type 0 = folder, type 1 = file.

The public app_key + user-agent are required because Fshare's API rejects
unknown clients ("Invalid User Agent"); both are overridable in advanced
settings, along with a bearer token you can paste from the website if the
automatic login ever stops working.
"""
import json
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

API_BASE = "https://api2.fshare.vn/api"   # login
WEB_BASE = "https://www.fshare.vn"        # v3 favorites / folder / download
DEFAULT_APP_KEY = "L2S7R6ZMagggC5wWkQhX2+aDi467PPuftWUMRFSn"
DEFAULT_USER_AGENT = "okhttp/3.6.0"
SESSION_TTL = 6 * 60 * 60                 # re-login after 6h


class FshareError(Exception):
    """Auth/network/API failure carrying a user-facing message."""


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, msg), level)


def _setting(key):
    return ADDON.getSetting(key)


def _app_key():
    return _setting("app_key") or DEFAULT_APP_KEY


def _user_agent():
    return _setting("user_agent") or DEFAULT_USER_AGENT


# --- session cache ---------------------------------------------------------

def _session_file():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return profile + "session.json"


def _load_session():
    path = _session_file()
    if not xbmcvfs.exists(path):
        return None
    try:
        with xbmcvfs.File(path) as fh:
            data = json.loads(fh.read())
    except (ValueError, IOError):
        return None
    if time.time() - data.get("ts", 0) > SESSION_TTL:
        return None
    return data


def _save_session(data):
    data = dict(data, ts=time.time())
    with xbmcvfs.File(_session_file(), "w") as fh:
        fh.write(json.dumps(data))
    return data


def _clear_session():
    path = _session_file()
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)


# --- low-level HTTP --------------------------------------------------------

def _request(url, method="GET", json_body=None, bearer=None):
    """Perform an HTTP request; return (status, parsed_json_or_text)."""
    headers = {"User-Agent": _user_agent(), "Accept": "application/json"}
    data = None
    if json_body is not None:
        data = json.dumps(json_body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    if bearer:
        headers["Authorization"] = "Bearer " + bearer

    req = Request(url, data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=20) as resp:
            raw = resp.read().decode("utf-8", "replace")
            status = resp.getcode()
    except HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace") if exc.fp else ""
        status = exc.code
    except URLError as exc:
        raise FshareError("Network error contacting Fshare: {}".format(exc.reason))

    try:
        return status, json.loads(raw)
    except ValueError:
        return status, raw


# --- auth ------------------------------------------------------------------

def _do_login():
    """Log in via api2 and return a session dict with bearer candidates."""
    manual = _setting("bearer_token").strip()
    if manual:
        # User pasted a token from the website; use it directly.
        return _save_session({"bearer": manual, "candidates": [manual]})

    email = _setting("email")
    password = _setting("password")
    if not email or not password:
        raise FshareError("Enter your Fshare email and password in add-on settings.")

    status, body = _request(
        API_BASE + "/user/login",
        method="POST",
        json_body={"app_key": _app_key(), "user_email": email, "password": password},
    )
    if status != 200 or not isinstance(body, dict) or not (body.get("session_id") or body.get("token")):
        msg = body.get("msg") if isinstance(body, dict) else str(body)[:200]
        raise FshareError("Fshare login failed: {}".format(msg or status))

    # The web API bearer is the session token; try session_id then token.
    candidates = [c for c in (body.get("session_id"), body.get("token")) if c]
    log("Logged in to Fshare for {}".format(email))
    return _save_session({"bearer": candidates[0], "candidates": candidates})


def _session(force=False):
    if not force:
        cached = _load_session()
        if cached:
            return cached
    return _do_login()


def _authed(url, method="GET", json_body=None):
    """Request with the bearer token, self-correcting the candidate and
    re-logging in on auth failure."""
    sess = _session()
    candidates = sess.get("candidates") or [sess.get("bearer")]

    for attempt in range(2):
        # Prefer the last-known-good bearer, then any other candidates.
        ordered = [sess.get("bearer")] + [c for c in candidates if c != sess.get("bearer")]
        for bearer in [b for b in ordered if b]:
            status, body = _request(url, method, json_body, bearer)
            if status not in (401, 403):
                if sess.get("bearer") != bearer:
                    sess["bearer"] = bearer
                    _save_session(sess)
                return status, body
        # All candidates rejected — force a fresh login and retry once.
        _clear_session()
        sess = _session(force=True)
        candidates = sess.get("candidates") or [sess.get("bearer")]

    raise FshareError("Fshare rejected the session (401). Check your email/password, "
                      "or paste a bearer token in advanced settings.")


# --- item parsing ----------------------------------------------------------

def _normalise(raw):
    """Map an Fshare item dict to {name, linkcode, is_folder}."""
    return {
        "name": raw.get("name") or "Untitled",
        "linkcode": raw.get("linkcode") or "",
        # type 0 = folder, type 1 = file
        "is_folder": str(raw.get("type", "0")) == "0",
    }


def _items(body):
    if isinstance(body, dict) and isinstance(body.get("items"), list):
        return [_normalise(i) for i in body["items"] if i.get("linkcode")]
    return []


# --- public API ------------------------------------------------------------

def get_favorites():
    """Return the account's favorites/bookmarks as normalised items."""
    status, body = _authed(WEB_BASE + "/api/v3/favorites/explore?sort=-modified")
    if status != 200:
        raise FshareError("Couldn't read favorites (HTTP {}).".format(status))
    return _items(body)


def list_folder(linkcode, page=1, per_page=100):
    """Return normalised items inside an Fshare folder."""
    qs = urlencode({"linkcode": linkcode, "page": page, "per-page": per_page})
    status, body = _authed("{}/api/v3/files/folder?{}".format(WEB_BASE, qs))
    if status != 200:
        raise FshareError("Couldn't list folder (HTTP {}).".format(status))
    return _items(body)


def resolve_download(linkcode):
    """Resolve a file linkcode to a direct, streamable URL."""
    qs = urlencode({"dl_type": "media", "linkcode": linkcode})
    status, body = _authed("{}/api/v3/files/download?{}".format(WEB_BASE, qs))
    # The endpoint returns the URL as a bare JSON string.
    if status == 200 and isinstance(body, str) and body.startswith("http"):
        return body
    if status == 200 and isinstance(body, dict) and body.get("location"):
        return body["location"]
    raise FshareError("Couldn't get download link (HTTP {}).".format(status))
