"""Home Media — Kodi video add-on entry point.

Kodi invokes this script with the plugin URL in sys.argv:
    argv[0]  plugin:// base path
    argv[1]  handle (int) used by xbmcplugin calls
    argv[2]  query string (?action=...&...)

Routing is a thin dispatch on the ``action`` query parameter so the add-on
stays dependency-free. Add new views by registering a handler in ROUTES.
"""
import sys

from resources.lib import router

if __name__ == "__main__":
    router.run(sys.argv)
